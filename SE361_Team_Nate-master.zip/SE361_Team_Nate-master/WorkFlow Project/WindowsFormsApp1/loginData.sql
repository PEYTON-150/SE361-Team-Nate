﻿CREATE TABLE [dbo].[Table]
(
	[userID] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [password] NCHAR(50) NOT NULL, 
    [access] NCHAR(10) NOT NULL
)
