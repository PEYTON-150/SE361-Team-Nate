INSERT INTO [dbo].[Raw Materials] ([Material], [Quantity on Hand], [Price Per Unit], [Who We Order From]) VALUES (N'Wood (lb)', 100, 4.36, N'Sorenson''s Forestson')
INSERT INTO [dbo].[Raw Materials] ([Material], [Quantity on Hand], [Price Per Unit], [Who We Order From]) VALUES (N'Nails (bundles of 100)', 100, 11.36, N'Skyforge')
INSERT INTO [dbo].[Raw Materials] ([Material], [Quantity on Hand], [Price Per Unit], [Who We Order From]) VALUES (N'Glue (Gallons)', 100, 20.67, N'Literally Just a Horse')
INSERT INTO [dbo].[Raw Materials] ([Material], [Quantity on Hand], [Price Per Unit], [Who We Order From]) VALUES (N'Glass (3x5 pains)', 100, 9.99, N'Shattered Dreams Hardware')
