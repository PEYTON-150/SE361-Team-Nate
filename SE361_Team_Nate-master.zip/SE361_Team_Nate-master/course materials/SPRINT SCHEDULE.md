# SE361_Team_Nate
SPRINT SCHEDULE
To-Do Date: Feb 4 at 11:59pm
TEAM MEETINGS (2-week Sprints)

SPRINT 0 (team formation, project selection, technologies/tools/platforms setup, etc.)

1/28 Sprint Planning

2/2 Daily Stand-up

2/4 Daily Stand-up

2/9 Daily Stand-up

2/11 Sprint Review/Demo, followed by a Sprint Retrospective and next Sprint planning

SPRINT 1

2/11 Daily Stand-up, Sprint planning

2/16 Daily Stand-up

2/18 Daily Stand-up

2/23 Daily Stand-up

2/25 Sprint Review/Demo, Sprint Retrospective, next Sprint planning

SPRINT 2

2/25 Daily Stand-up, Sprint Planning

3/02 Daily Stand-up

3/04 Daily Stand-up

3/09 Daily Stand-up--followed by a Design & Code Review session

3/11 Sprint Review/Demo, Sprint Retrospective, next Sprint planning

SPRINT 3

3/11 Daily Stand-up, Sprint Planning

3/16 Daily Stand-up

3/18 Daily Stand-up

3/23 Daily Stand-up--followed by a Design & Code Review session

3/25 Sprint Review/Demo, Sprint Retrospective, next Sprint Planning

SPRINT 4

3/25 Daily Stand-up, Sprint planning

3/30 Daily Stand-up

4/01 Daily Stand-up

4/06 Daily Stand-up--followed by a Design & Code Review session

4/08 Sprint Review/Demo, Sprint Retrospective

SPRINT 5

4/08 Stand-up, Sprint Planning

4/13 Daily Stand-up

4/15 Daily Stand-up

4/20 Daily Stand-up

4/22 Daily Stand-up--followed by a Design & Code Review session

4/27 Final Sprint Review/Demo
